function rhoG = B_spectral_radius(A,omega,tau)
    % B_spectral_radius: Υπολογισμός φασματικής ακτίνας του επαναληπτικού πίνακα G

    n = rows(A);

    D  = diag(diag(A));
    CL = -tril(A,-1);  % κάτω μέρος
    CU = -triu(A, 1);  % άνω μέρος

    L = D \ CL;
    U = D \ CU;

    G = (eye(n) - omega*L) \ ( (1-tau)*eye(n) + (tau-omega)*L + tau*U );

    rhoG = max(abs(eig(G)));
end
