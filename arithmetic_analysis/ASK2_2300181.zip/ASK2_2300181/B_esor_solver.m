function [x,it,converged] = B_esor_solver(a,b,c,d,omega,tau,eps_tol,maxit)
    % B_esor_solver: Επαναληπτική μέθοδος ESOR για τριδιαγώνιο σύστημα

    n = length(b);

    x_old = d(:);
    x_new = x_old;

    converged = false;

    for it = 1:maxit

        if n >= 2
            x_new(1) = (1 - tau)*x_old(1) ...
                       + tau * ( -c(1)/b(1) ) * x_old(2) ...
                       + d(1)/b(1);
        else
            x_new(1) = (1 - tau)*x_old(1) + d(1)/b(1);
        end

        for i = 2:n-1
            x_new(i) = (1 - tau)*x_old(i) ...
                       + omega      * ( -a(i)/b(i) ) * x_new(i-1) ...
                       + (tau-omega)* ( -a(i)/b(i) ) * x_old(i-1) ...
                       + tau        * ( -c(i)/b(i) ) * x_old(i+1) ...
                       + d(i)/b(i);
        end

        if n >= 2
            x_new(n) = (1 - tau)*x_old(n) ...
                       + omega      * ( -a(n)/b(n) ) * x_new(n-1) ...
                       + (tau-omega)* ( -a(n)/b(n) ) * x_old(n-1) ...
                       + d(n)/b(n);
        end

        if norm(x_new - x_old, Inf) < eps_tol
            converged = true;
            x = x_new;
            return;
        end

        x_old = x_new;
    end

    x = x_new;
end
