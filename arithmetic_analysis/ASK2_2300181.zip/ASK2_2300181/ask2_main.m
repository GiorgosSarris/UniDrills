function ask2_main()
  % Ασκηση 2 - Αριθμητική Ανάλυση
  % Κεντρικό πρόγραμμα που τρέχει ΟΛΗ την εργασία

  format long e;
  eps_tol = 1e-6;
  maxit   = 10000;
  ns      = [10 100];
  params  = [1 2; 2 1];

  tau_plot = 1.2;

  for in = 1:length(ns)
    n = ns(in);

    for ip = 1:rows(params)
      alpha = params(ip,1);
      beta  = params(ip,2);

      printf("\n==============================\n");
      printf("n = %d, alpha = %.1f, beta = %.1f\n", n, alpha, beta);
      printf("==============================\n");

      % --- Κατασκευή συστήματος ---
      [A,a,b,c] = build_tridiag(n, alpha, beta);

      x_true = ones(n,1);
      d      = A * x_true;

      % ==========================
      % ΜΕΡΟΣ Α: THOMAS
      % ==========================
      tic;
      x_th = A_thomas(a,b,c,d);
      time_th = toc;

      [errx_th, errr_th] = compute_errors(A,d,x_th,x_true);

      printf("Thomas: time = %.4e  errx = %.3e  errr = %.3e\n", ...
             time_th, errx_th, errr_th);

      % ==========================
      % ΜΕΡΟΣ Α: GAUSS
      % ==========================
      tic;
      x_g = A_gauss_nopivot(A,d);
      time_g = toc;

      [errx_g, errr_g] = compute_errors(A,d,x_g,x_true);

      printf("Gauss(no pivot): time = %.4e  errx = %.3e  errr = %.3e\n", ...
             time_g, errx_g, errr_g);

      % ==========================
      % ΜΕΡΟΣ Β: ESOR
      % ==========================

      if (in == 1 && ip == 1)
        % ====== (α) Γραφική iterations vs ω ======
        omegas   = 0.1:0.1:1.9;
        it_omega = zeros(size(omegas));

        for k = 1:length(omegas)
          omega = omegas(k);
          [~, it, ok] = B_esor_solver(a,b,c,d,omega,tau_plot,eps_tol,maxit);
          if ok
            it_omega(k) = it;
          else
            it_omega(k) = NaN;
          endif
        endfor

        fig = figure();
        plot(omegas, it_omega, "-o");
        grid on;
        xlabel("ω"); ylabel("iterations");
        title(sprintf("ESOR iterations vs ω (n=%d, α=%.1f, β=%.1f, τ=%.1f)", ...
                       n, alpha, beta, tau_plot));
        drawnow;
        saveas(fig, "ESOR_plot_main_case.png");


        % ====== (β) Βέλτιστα (ω,τ) ======
        taus = 0.1:0.1:1.9;

        best_iters = Inf;
        best_omega = NaN;
        best_tau   = NaN;
        best_rho   = NaN;

        for omega = omegas
          for tau = taus
            [~, it, ok] = B_esor_solver(a,b,c,d,omega,tau,eps_tol,maxit);
            if ok && it < best_iters && omega == tau
              best_iters = it;
              best_omega = omega;
              best_tau   = tau;
              best_rho   = B_spectral_radius(A,omega,tau);
            endif
          endfor
        endfor

        printf("ESOR best: ω = %.2f  τ = %.2f  it = %d  rho(G) = %.6f\n", ...
               best_omega, best_tau, best_iters, best_rho);

        [x_best,~,~] = B_esor_solver(a,b,c,d,best_omega,best_tau,eps_tol,maxit);
        [errx_es, errr_es] = compute_errors(A,d,x_best,x_true);
        printf("ESOR(best): errx = %.3e  errr = %.3e\n", errx_es, errr_es);

      else
        % Για τα άλλα στιγμιότυπα δεν κάνουμε scan ούτε plot
        omega = 1.2;
        tau   = 1.2;
        [x_es, it, ok] = B_esor_solver(a,b,c,d,omega,tau,eps_tol,maxit);
        [errx_es, errr_es] = compute_errors(A,d,x_es,x_true);

        printf("ESOR (χωρίς πλήρη μελέτη): ω=%.2f τ=%.2f  it=%d  errx=%.3e errr=%.3e\n", ...
               omega, tau, it, errx_es, errr_es);
      endif

    endfor   % <-- έκλεινε λάθος εδώ!
  endfor     % <-- έλειπε!

  printf("\nΤέλος ask2_main.\n");
endfunction



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ΒΟΗΘΗΤΙΚΕΣ ΥΛΟΠΟΙΗΣΕΙΣ ΜΕΣΑ ΣΤΟ ΙΔΙΟ ΑΡΧΕΙΟ     %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [A,a,b,c] = build_tridiag(n, alpha, beta)
  a = -alpha * ones(n,1);
  b = 4      * ones(n,1);
  c = -beta  * ones(n,1);

  a(1)   = 0;
  c(end) = 0;

  A = diag(b) + diag(a(2:end), -1) + diag(c(1:end-1), 1);
endfunction


function [errx, errr] = compute_errors(A,d,x_num,x_true)
  dx = x_num - x_true;
  r  = d - A*x_num;

  errx = norm(dx, Inf) / norm(x_true, Inf);
  errr = norm(r,  Inf) / norm(x_true, Inf);
endfunction
