function x = A_thomas(a,b,c,d)
    % A_thomas: Λύνει τριδιαγώνιο σύστημα Ax=d με τη μέθοδο Thomas
    % a = κάτω διαγώνιος (a(1)=0)
    % b = κύρια διαγώνιος
    % c = άνω διαγώνιος (c(n)=0)
    % d = RHS

    n = length(b);

    c_star = zeros(n,1);
    d_star = zeros(n,1);

    c_star(1) = c(1) / b(1);
    d_star(1) = d(1) / b(1);

    for i = 2:n-1
        denom     = b(i) - a(i)*c_star(i-1);
        c_star(i) = c(i) / denom;
        d_star(i) = (d(i) - a(i)*d_star(i-1)) / denom;
    end

    denom     = b(n) - a(n)*c_star(n-1);
    d_star(n) = (d(n) - a(n)*d_star(n-1)) / denom;

    x = zeros(n,1);
    x(n) = d_star(n);

    for i = n-1:-1:1
        x(i) = d_star(i) - c_star(i)*x(i+1);
    end
end
