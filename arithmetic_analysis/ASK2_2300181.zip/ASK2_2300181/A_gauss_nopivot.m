function x = A_gauss_nopivot(A,b)
    % A_gauss_nopivot: Κλασική απαλοιφή Gauss χωρίς pivoting

    [n, m] = size(A);
    if n ~= m
        error("A must be square");
    end

    Ab = [A b(:)];

    for k = 1:n-1
        if Ab(k,k) == 0
            error("Zero pivot at row %d (no pivoting allowed)", k);
        end

        for i = k+1:n
            m_ik = Ab(i,k) / Ab(k,k);
            Ab(i,k:n+1) = Ab(i,k:n+1) - m_ik * Ab(k,k:n+1);
        end
    end

    x = zeros(n,1);
    for i = n:-1:1
        x(i) = (Ab(i,end) - Ab(i,i+1:n)*x(i+1:n)) / Ab(i,i);
    end
end
