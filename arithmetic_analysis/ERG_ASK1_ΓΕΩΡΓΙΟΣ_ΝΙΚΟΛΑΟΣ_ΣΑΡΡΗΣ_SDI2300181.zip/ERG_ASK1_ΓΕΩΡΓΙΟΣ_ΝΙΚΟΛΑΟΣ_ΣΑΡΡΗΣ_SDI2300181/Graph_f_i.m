function Graph_f_i()
% =============================================
% Συνάρτηση: Graph_f_i
% Σχεδίαση των f1(x) και f2(x)
% =============================================

clc;

% Ορισμός συναρτήσεων
f1 = @(x) ((x + 1).^3) .* (x - 2);
f2 = @(x) exp(x) - x.^2 - 2;

% Περιοχή σχεδίασης (κοινό x για απλότητα)
x = linspace(-3, 3, 400);
y1 = f1(x);
y2 = f2(x);

% Ρίζες (από τους υπολογισμούς σου)
r1a = -1;
r1b = 2;
r2  = 1.319;   % περίπου

% Δημιουργία γραφήματος
figure;
hold on; grid on;

plot(x, y1, 'b-', 'LineWidth', 1.5);
plot(x, y2, 'r-', 'LineWidth', 1.5);

% Άξονας x χωρίς yline (συμβατό με Octave)
plot([min(x) max(x)], [0 0], 'k--', 'LineWidth', 1);

% Επισήμανση ριζών
plot(r1a, f1(r1a), 'bo', 'MarkerFaceColor', 'b');
plot(r1b, f1(r1b), 'bo', 'MarkerFaceColor', 'b');
plot(r2,  f2(r2),  'ro', 'MarkerFaceColor', 'r');

xlabel('x');
ylabel('f(x)');
title('Γραφική παράσταση των f_1(x) και f_2(x)');
legend('f_1(x) = (x+1)^3(x-2)', 'f_2(x) = e^x - x^2 - 2', 'Άξονας x', 'Ρίζες', 'Location', 'northwest');

hold off;

end
