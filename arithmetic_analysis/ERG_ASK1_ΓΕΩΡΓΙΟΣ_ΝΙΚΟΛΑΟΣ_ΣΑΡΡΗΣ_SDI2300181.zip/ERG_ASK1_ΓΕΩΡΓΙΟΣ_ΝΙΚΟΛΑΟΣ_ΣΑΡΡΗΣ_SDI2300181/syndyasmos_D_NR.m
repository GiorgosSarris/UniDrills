function syndyasmos_D_NR()
% Συνδυασμός Διχοτόμησης & Newton–Raphson
% Καλύπτει τα 1.1A, 1.2 και 1.3 της εκφώνησης.

eps_dix = 0.5e-2;   % 0.005
eps_NR  = 0.5e-6;   % 0.0000005

% f1(x) = (x+1)^3 (x−2)
f1 = @(x) ((x + 1).^3) .* (x - 2);
df1 = @(x) 3*(x + 1).^2 .* (x - 2) + (x + 1).^3;

%Ρίζα κοντά στο -1
a = -2; 
b = 1;
while (b - a)/2 > eps_dix
    c = (a + b)/2;
    if f1(a)*f1(c) < 0
        b = c;
    else
        a = c;
    end
end
x0_1 = (a + b)/2;

X1 = [];                        % διαδοχικά x_n
x_prev = x0_1 + 2*eps_NR;       
x = x0_1;
n1 = 0;
while abs(x - x_prev) > eps_NR
    x_prev = x;
    x = x - f1(x)/df1(x);
    X1(end+1) = x;
    n1 = n1 + 1;
end
xn_1 = x;

%Ρίζα κοντά στο 2
a = 1; 
b = 3;
while (b - a)/2 > eps_dix
    c = (a + b)/2;
    if f1(a)*f1(c) < 0
        b = c;
    else
        a = c;
    end
end
x0_2 = (a + b)/2;

X2 = [];
x_prev = x0_2 + 2*eps_NR;
x = x0_2;
n2 = 0;
while abs(x - x_prev) > eps_NR
    x_prev = x;
    x = x - f1(x)/df1(x);
    X2(end+1) = x;
    n2 = n2 + 1;
end
xn_2 = x;

% f2(x) = e^x − x^2 − 2
f2 = @(x) exp(x) - x.^2 - 2;
df2 = @(x) exp(x) - 2*x;

a = 1; 
b = 2;
while (b - a)/2 > eps_dix
    c = (a + b)/2;
    if f2(a)*f2(c) < 0
        b = c;
    else
        a = c;
    end
end
x0_3 = (a + b)/2;

X3 = [];
x_prev = x0_3 + 2*eps_NR;
x = x0_3;
n3 = 0;
while abs(x - x_prev) > eps_NR
    x_prev = x;
    x = x - f2(x)/df2(x);
    X3(end+1) = x;
    n3 = n3 + 1;
end
xn_3 = x;

% ΤΕΛΙΚΕΣ ΡΙΖΕΣ (1.1A)
fprintf('\nΤελικές προσεγγιστικές ρίζες (1.1A)\n');
fprintf('---------------------------------------------\n');
fprintf(' f1 (ρίζα -1):  x0 = %.8f,  xn = %.8f,  n = %d\n', x0_1, xn_1, n1);
fprintf(' f1 (ρίζα 2):   x0 = %.8f,  xn = %.8f,  n = %d\n', x0_2, xn_2, n2);
fprintf(' f2:            x0 = %.8f,  xn = %.8f,  n = %d\n', x0_3, xn_3, n3);
fprintf('---------------------------------------------\n');

% ΠΙΝΑΚΑΣ 1 – Διαδοχικές επαναλήψεις Newton (1.2)
fprintf('\nΠΙΝΑΚΑΣ 1 – Διαδοχικές Επαναλήψεις Newton (1.2)\n');

fprintf('\n--- f1 (ρίζα -1) ---\n');
fprintf(' n        x_n\n');
for k = 1:length(X1)
    fprintf('%2d     %.10f\n', k-1, X1(k));
end

fprintf('\n--- f1 (ρίζα 2) ---\n');
fprintf(' n        x_n\n');
for k = 1:length(X2)
    fprintf('%2d     %.10f\n', k-1, X2(k));
end

fprintf('\n--- f2 ---\n');
fprintf(' n        x_n\n');
for k = 1:length(X3)
    fprintf('%2d     %.10f\n', k-1, X3(k));
end

% ΠΙΝΑΚΑΣ 2 – Μελέτη Ταχύτητας Σύγκλισης (1.3)
fprintf('\nΠΙΝΑΚΑΣ 2 – Μελέτη Ταχύτητας Σύγκλισης (1.3)\n');

% f1, ρίζα -1
xi = -1;
err = abs(X1 - xi);

fprintf('\nΓια f1 (ρίζα -1):\n');
fprintf(' n     |ε_n|            |ε_{n+1}|/|ε_n|        |ε_{n+1}|/|ε_n|^2\n');
for i = 1:length(err)-1
    q1 = err(i+1)/err(i);
    q2 = err(i+1)/(err(i)^2);
    fprintf('%2d    %.3e      %.3e          %.3e\n', i-1, err(i), q1, q2);
end

% f2, ρίζα άγνωστη -διαφορές διαδοχικών x_n
d = abs(diff(X3));

fprintf('\nΓια f2 (ρίζα άγνωστη):\n');
fprintf(' n     |x_{n+1}-x_n|    p=1                   p=2\n');
for i = 2:length(d)
    q1 = d(i)/d(i-1);
    q2 = d(i)/(d(i-1)^2);
    fprintf('%2d    %.3e      %.3e            %.3e\n', i-1, d(i-1), q1, q2);
end

end
