clc;clear;

syndyasmos_D_NR();
syndyasmos_D_T();     
Graph_f_i();
fprintf('--- Τέλος εκτέλεσης προγράμματος ---\n');
