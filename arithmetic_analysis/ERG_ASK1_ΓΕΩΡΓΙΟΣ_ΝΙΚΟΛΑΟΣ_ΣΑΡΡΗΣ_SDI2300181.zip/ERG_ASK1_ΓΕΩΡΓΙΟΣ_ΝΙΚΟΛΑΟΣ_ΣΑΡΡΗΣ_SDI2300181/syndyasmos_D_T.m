function syndyasmos_D_T()
% 1.5 – Συνδυασμός Διχοτόμησης & Μεθόδου Τέμνουσας (Secant)
% Επαναλαμβάνει τα 1.1–1.3 για τη μέθοδο τέμνουσας:
%  - Πίνακας 3: συνοπτικά αποτελέσματα
%  - Πίνακας 3A: διαδοχικές επαναλήψεις τέμνουσας
%  - Πίνακας 4: μελέτη ταχύτητας σύγκλισης
eps_dix = 0.5e-2;   
eps_T   = 0.5e-6;   

% f1(x) = (x+1)^3 (x−2)
f1 = @(x) ((x+1).^3).*(x-2);

%Ριζα -1
a1 = -2; 
b1 = 1;
while (b1-a1)/2 > eps_dix
    c = (a1+b1)/2;
    if f1(a1)*f1(c) < 0
        b1 = c;
    else
        a1 = c;
    end
end
x0_1 = (a1+b1)/2;

XS1 = [];               % Διαδοχικές προσεγγίσεις τέμνουσας
x_prev = a1;
x = b1;
iter1 = 0;
while abs(x - x_prev) > eps_T
    x_new = x - f1(x) * (x - x_prev) / (f1(x) - f1(x_prev));
    x_prev = x;
    x = x_new;
    XS1(end+1) = x;
    iter1 = iter1 + 1;
end
xn_1 = x;

% Ριζα 2
a2 = 1; 
b2 = 3;
while (b2-a2)/2 > eps_dix
    c = (a2+b2)/2;
    if f1(a2)*f1(c) < 0
        b2 = c;
    else
        a2 = c;
    end
end
x0_2 = (a2+b2)/2;

XS2 = [];
x_prev = a2;
x = b2;
iter2 = 0;
while abs(x - x_prev) > eps_T
    x_new = x - f1(x) * (x - x_prev) / (f1(x) - f1(x_prev));
    x_prev = x;
    x = x_new;
    XS2(end+1) = x;
    iter2 = iter2 + 1;
end
xn_2 = x;
% f2(x) = e^x − x^2 − 2
f2 = @(x) exp(x) - x.^2 - 2;

a3 = 1; 
b3 = 2;
while (b3-a3)/2 > eps_dix
    c = (a3+b3)/2;
    if f2(a3)*f2(c) < 0
        b3 = c;
    else
        a3 = c;
    end
end
x0_3 = (a3+b3)/2;

XS3 = [];
x_prev = a3;
x = b3;
iter3 = 0;
while abs(x - x_prev) > eps_T
    x_new = x - f2(x) * (x - x_prev) / (f2(x) - f2(x_prev));
    x_prev = x;
    x = x_new;
    XS3(end+1) = x;
    iter3 = iter3 + 1;
end
xn_3 = x;

% ΠΙΝΑΚΑΣ 3 – αποτελέσματα
fprintf('\nΠΙΝΑΚΑΣ 3 – Συνδυασμός Διχοτόμησης και Τέμνουσας\n');
fprintf('------------------------------------------------------------\n');
fprintf(' f_i     [a,b]             x0               xn         n\n');
fprintf('------------------------------------------------------------\n');
fprintf(' f1(1)   [%.2f, %.2f]   %.8f     %.8f   %d\n', a1, b1, x0_1, xn_1, iter1);
fprintf(' f1(2)   [%.2f, %.2f]   %.8f     %.8f   %d\n', a2, b2, x0_2, xn_2, iter2);
fprintf(' f2      [%.2f, %.2f]   %.8f     %.8f   %d\n', a3, b3, x0_3, xn_3, iter3);
fprintf('------------------------------------------------------------\n');

% ΠΙΝΑΚΑΣ 3A – Διαδοχικές επαναλήψεις Τέμνουσας (αντίστοιχο 1.2)
fprintf('\nΠΙΝΑΚΑΣ 3A – Διαδοχικές Επαναλήψεις Τέμνουσας (1.5)\n');

fprintf('\n--- f1 (ρίζα -1) ---\n');
fprintf(' n        x_n\n');
for k = 1:length(XS1)
    fprintf('%2d     %.10f\n', k-1, XS1(k));
end

fprintf('\n--- f1 (ρίζα 2) ---\n');
fprintf(' n        x_n\n');
for k = 1:length(XS2)
    fprintf('%2d     %.10f\n', k-1, XS2(k));
end

fprintf('\n--- f2 ---\n');
fprintf(' n        x_n\n');
for k = 1:length(XS3)
    fprintf('%2d     %.10f\n', k-1, XS3(k));
end

% ΠΙΝΑΚΑΣ 4 – Μελέτη ταχύτητας σύγκλισης για τέμνουσα (αντίστοιχο 1.3)
fprintf('\nΠΙΝΑΚΑΣ 4 – Μελέτη Ταχύτητας Σύγκλισης (Τέμνουσα)\n');

% f1, ρίζα -1 (γνωστή)
xi = -1;
errS1 = abs(XS1 - xi);

fprintf('\nΓια f1 (ρίζα -1):\n');
fprintf(' n     |ε_n|            |ε_{n+1}|/|ε_n|        |ε_{n+1}|/|ε_n|^2\n');
for i = 1:length(errS1)-1
    q1 = errS1(i+1)/errS1(i);
    q2 = errS1(i+1)/(errS1(i)^2);
    fprintf('%2d    %.3e      %.3e          %.3e\n', i-1, errS1(i), q1, q2);
end

% f2, ρίζα άγνωστη - διαφορές διαδοχικών x_n
dS3 = abs(diff(XS3));

fprintf('\nΓια f2 (ρίζα άγνωστη):\n');
fprintf(' n     |x_{n+1}-x_n|    p=1                   p=2\n');
for i = 2:length(dS3)
    q1 = dS3(i)/dS3(i-1);
    q2 = dS3(i)/(dS3(i-1)^2);
    fprintf('%2d    %.3e      %.3e            %.3e\n', i-1, dS3(i-1), q1, q2);
end

end