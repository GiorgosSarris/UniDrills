function [lambda, x, itcount, exec_time] = inverse_power_shift(A, q, x0, eps, maxiter)
  n=length(x0);
  I=eye(n);
  x=x0/norm(x0);
  itcount=0;
  tic;

  for k=1:maxiter
    itcount=k;
    y=(A-q*I)\x;
    % κανονικοποίηση
    x_new=y/norm(y);
    if norm(x_new-x)<eps
      x=x_new;
      break;
    end
    x=x_new;
  end
  exec_time=toc;

  lambda=(x' * A * x)/(x' * x);

end
