function [lambda, x, itcount, exec_time] = rayleigh_inverse(A, x0, eps, maxiter)
  n=length(x0);
  I=eye(n);
  x=x0/norm(x0);
  lambda=(x' * A * x)/(x' * x);
  tic;

  for k= 1:maxiter
    itcount=k;
    y=(A-lambda*I)\x;
    % κανονικοποίηση
    x_new=y/norm(y);
    % νέο Rayleigh quotient
    lambda_new=(x_new' * A * x_new)/(x_new' * x_new);
    % έλεγχος σύγκλισης
    if abs(lambda_new-lambda)<eps
      x=x_new;
      lambda=lambda_new;
      break;
    end
    x=x_new;
    lambda=lambda_new;
  end
  exec_time=toc;

end
