close all;

fprintf('  ΕΡΓΑΣΙΑ 3 – ΑΡΙΘΜΗΤΙΚΗ ΑΝΑΛΥΣΗ\n');

%% Κοινές παράμετροι
eps=0.5e-6;
maxiter=1000;

%% ΑΣΚΗΣΗ 1
fprintf('ΑΣΚΗΣΗ 1\n');

A = [ 16  -8   2   1;
       2 -12   1   0;
      -1   1  -4   1;
       0  -1   2   3 ];
x0=ones(4,1);
% Ακριβείς ιδιοτιμές για σύγκριση
[V,D]=eig(A);
eigvals=diag(D);
[~, idx1]=max(abs(eigvals));
[~, idxn]=min(abs(eigvals));
lambda1=eigvals(idx1);
lambdan=eigvals(idxn);

fprintf('Ακριβείς ιδιοτιμές:\n');
disp(eigvals.');

%%Προσέγγιση λ1
q_vals1=lambda1- (0.3:0.1:0.9);
fprintf('\nΠροσέγγιση λ1 (μέγιστη |λ|)\n');
fprintf('q\t\titer\t\tlambda\t\ttime\n');

for q = q_vals1
  [lam, x, itc, t] = inverse_power_shift(A, q, x0, eps, maxiter);
  fprintf('%.2f\t\t%d\t\t%.6f\t%.6f\n', q, itc, lam, t);
end

%%Προσέγγιση λn
q_valsN=lambdan+ (0.3:0.1:0.9);

fprintf('\nΠροσέγγιση λn (ελάχιστη |λ|)\n');
fprintf('q\t\titer\t\tlambda\t\ttime\n');

for q=q_valsN
  [lam, x, itc, t] = inverse_power_shift(A, q, x0, eps, maxiter);
  fprintf('%.2f\t\t%d\t\t%.6f\t%.6f\n', q, itc, lam, t);
end

%% ΑΣΚΗΣΗ 2
fprintf('\nΑΣΚΗΣΗ 2\n');

%% Πίνακες γειτνίασης
A1 = [
    0 1 1 1 0 0 0 0;
    1 0 1 0 0 0 1 0;
    1 1 0 1 1 0 0 0;
    1 0 1 0 0 0 0 1;
    0 0 1 0 0 1 0 0;
    0 0 0 0 1 0 1 1;
    0 1 0 0 0 1 0 1;
    0 0 0 1 0 1 1 0
];
      
% Ιδιοτιμές πίνακα γειτνίασης
eigvalsA1 = eig(A1);

lambda1A1 = max(eigvalsA1);
lambdaNA1 = min(eigvalsA1);


x0 = ones(size(A1,1),1);

%%Hoffman bound
chi_lower = 1 + lambda1A1 / abs(lambdaNA1);
fprintf('Κάτω φράγμα χ (Hoffman): %.4f\n', chi_lower);

%% ΑΣΚΗΣΗ 2Α – Τροποποιημένη αντίστροφη μέθοδος
fprintf('\nΆσκηση 2Α – Modified Inverse Power\n');

q1 = lambda1A1 - 0.2;
qN = lambdaNA1 + 0.2;

[lam1_mod, x1_mod, it1_mod, t1_mod] = ...
  inverse_power_shift(A1, q1, x0, eps, maxiter);

[lamN_mod, xN_mod, itN_mod, tN_mod] = ...
  inverse_power_shift(A1, qN, x0, eps, maxiter);

fprintf('λ1 ≈ %.6f | iter = %d | time = %.6f\n', lam1_mod, it1_mod, t1_mod);
fprintf('λn ≈ %.6f | iter = %d | time = %.6f\n', lamN_mod, itN_mod, tN_mod);

%% ΑΣΚΗΣΗ 2Β – Rayleigh Quotient Iteration
fprintf('\nΆσκηση 2Β – Rayleigh Inverse\n');

[lam1_ray, x1_ray, it1_ray, t1_ray] = ...
  rayleigh_inverse(A1, x0, eps, maxiter);

fprintf('λ ≈ %.6f | iter = %d | time = %.6f\n', lam1_ray, it1_ray, t1_ray);

%% ΣΥΓΚΡΙΣΗ
fprintf('\nΣύγκριση χρόνων:\n');
fprintf('Modified: %.6f sec\n', t1_mod);
fprintf('Rayleigh: %.6f sec\n', t1_ray);

if t1_ray < t1_mod
  fprintf('Η Rayleigh είναι ταχύτερη (όπως αναμένεται).\n');
else
  fprintf('Η Modified είναι ταχύτερη σε αυτή την περίπτωση.\n');
end
